A Python interface to Aliyun Web Services
